package com.knifesurge.KnifeGraphics;

import java.beans.ConstructorProperties;

public class KnifeColor
{
	/** A special number to convert int RGB values to float RGB vlaues **/
	private static final float specnum = 1/255f;
	public static final KnifeColor white		= new KnifeColor(specnum*255, specnum*255, specnum*255);
	public static final KnifeColor WHITE = white;
	public static final KnifeColor lightGray	= new KnifeColor(specnum*193, specnum*193, specnum*193);
	public static final KnifeColor LIGHT_GRAY = lightGray;
	public static final KnifeColor gray			= new KnifeColor(specnum*128, specnum*128, specnum*128);
	public static final KnifeColor GRAY = gray;
	public static final KnifeColor darkGray		= new KnifeColor(specnum*64, specnum*64, specnum*64);
	public static final KnifeColor DARK_GRAY = darkGray;
	public static final KnifeColor black		= new KnifeColor(specnum*0, specnum*0, specnum*0);
	public static final KnifeColor BLACK = black;
	public static final KnifeColor red			= new KnifeColor(specnum*255, specnum*0, specnum*0);
	public static final KnifeColor RED = red;
	public static final KnifeColor pink			= new KnifeColor(specnum*255, specnum*175, specnum*175);
	public static final KnifeColor PINK = pink;
	public static final KnifeColor orange		= new KnifeColor(specnum*255, specnum*200, specnum*0);
	public static final KnifeColor ORANGE = orange;
	public static final KnifeColor yellow		= new KnifeColor(specnum*255, specnum*255, specnum*0);
	public static final KnifeColor YELLOW = yellow;
	public static final KnifeColor green		= new KnifeColor(specnum*0, specnum*255, specnum*0);
	public static final KnifeColor GREEN = green;
	public static final KnifeColor magenta		= new KnifeColor(specnum*255, specnum*0, specnum*255);
	public static final KnifeColor MAGENTA = magenta;
	public static final KnifeColor cyan			= new KnifeColor(specnum*0, specnum*255, specnum*255);
	public static final KnifeColor CYAN = cyan;
	public static final KnifeColor blue			= new KnifeColor(specnum*0, specnum*0, specnum*255);
	public static final KnifeColor BLUE = blue;
	
	public static int value = 0;
	public static float[] fvalue = null;
	private static float[] frgbvalue = null;
	
	private static boolean checkvalue()
	{
		if(fvalue == null)
			return false;
		return true;
	}
	
	public static float getRed()
	{
		if(checkvalue())
			return fvalue[0];
		return ((value >> 16) & 0xFF)/255;
	}
	
	public static float getGreen()
	{
		if(checkvalue())
			return fvalue[1];
		return ((value >> 8) & 0xFF)/255;
	}
	
	public static float getBlue()
	{
		if(checkvalue())
			return fvalue[2];
		return ((value >> 0) & 0xFF)/255;
	}
	
	@ConstructorProperties({"red", "green", "blue", "alpha"})
	public KnifeColor(int r, int g, int b, int a)
	{
		value = ((a & 0xFF) << 24) |
				((r & 0xFF) << 16) |
				((g & 0xFF) << 8) |
				((b & 0xFF) << 0);
		testColorValueRange(r,g,b,a);
	}
	
	public KnifeColor(int r, int g, int b)
	{
		this(r, g, b, 255);
	}
	
	public KnifeColor(int rgb)
	{
		value = 0xff000000 | rgb;
	}
	
	public KnifeColor(int rgba, boolean hasalpha) {
        if (hasalpha) {
            value = rgba;
        } else {
            value = 0xff000000 | rgba;
        }
    }
	
	public KnifeColor(float r, float g, float b)
	{
		this( (int) (r*255+0.5), (int) (g*255+0.5), (int) (b*255+0.5));
		testColorValueRange(r,g,b,1.0f);
		frgbvalue = new float[4];
		frgbvalue[0] = r;
		frgbvalue[1] = g;
		frgbvalue[2] = b;
		frgbvalue[3] = 1.0f;
		fvalue = frgbvalue;
	}
	
	public KnifeColor(float r, float g, float b, float a) {
        this((int)(r*255+0.5), (int)(g*255+0.5), (int)(b*255+0.5), (int)(a*255+0.5));
        frgbvalue = new float[4];
        frgbvalue[0] = r;
        frgbvalue[1] = g;
        frgbvalue[2] = b;
        frgbvalue[3] = a;
        fvalue = frgbvalue;
    }
	
	/**
     * Checks the color integer components supplied for validity.
     * Throws an {@link IllegalArgumentException} if the value is out of
     * range.
     * @param r the Red component
     * @param g the Green component
     * @param b the Blue component
     **/
    private static void testColorValueRange(int r, int g, int b, int a) {
        boolean rangeError = false;
        String badComponentString = "";

        if ( a < 0 || a > 255) {
            rangeError = true;
            badComponentString = badComponentString + " Alpha";
        }
        if ( r < 0 || r > 255) {
            rangeError = true;
            badComponentString = badComponentString + " Red";
        }
        if ( g < 0 || g > 255) {
            rangeError = true;
            badComponentString = badComponentString + " Green";
        }
        if ( b < 0 || b > 255) {
            rangeError = true;
            badComponentString = badComponentString + " Blue";
        }
        if ( rangeError == true ) {
        throw new IllegalArgumentException("Color parameter outside of expected range:"
                                           + badComponentString);
        }
    }
	
    /**
     * Checks the color <code>float</code> components supplied for
     * validity.
     * Throws an <code>IllegalArgumentException</code> if the value is out
     * of range.
     * @param r the Red component
     * @param g the Green component
     * @param b the Blue component
     **/
    private static void testColorValueRange(float r, float g, float b, float a) {
        boolean rangeError = false;
        String badComponentString = "";
        if ( a < 0.0 || a > 1.0) {
            rangeError = true;
            badComponentString = badComponentString + " Alpha";
        }
        if ( r < 0.0 || r > 1.0) {
            rangeError = true;
            badComponentString = badComponentString + " Red";
        }
        if ( g < 0.0 || g > 1.0) {
            rangeError = true;
            badComponentString = badComponentString + " Green";
        }
        if ( b < 0.0 || b > 1.0) {
            rangeError = true;
            badComponentString = badComponentString + " Blue";
        }
        if ( rangeError == true ) {
        throw new IllegalArgumentException("Color parameter outside of expected range:"
                                           + badComponentString);
        }
    }
}
